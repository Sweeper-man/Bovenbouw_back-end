<!-- jouw HTML met de inhoud over onderwerp 4 komt hier... -->
<img src="images/f1.jpg">
Formule 1, officieel de FIA Formula One World Championship, is de hoogste klasse in het formuleracen. 
Deze tak van autosport betreft het racen in speciaal voor dit doel ontwikkelde auto's met open wielkasten. 
Formule 1 wordt meer algemeen tevens gezien als de hoogste klasse in de autosport.