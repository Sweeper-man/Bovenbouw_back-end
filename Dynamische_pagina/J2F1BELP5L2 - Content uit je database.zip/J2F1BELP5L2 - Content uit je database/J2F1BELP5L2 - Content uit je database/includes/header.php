<!-- jouw HTML voor een Header komt hier... 
Gebruik hier tenminste een header afbeelding en een menu
Zorg dat je in het menu bij elk item een url parameter zet
om te bepalen welke inhoud er ingeladen moet worden in je html
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <ul>
        <a href="index.php?page=onderwerp1&id=1">Badminton</a>
        <a href="index.php?page=onderwerp2&id=2">Kickoxen</a>
        <a href="index.php?page=onderwerp3&id=3">Taekwondo</a>
        <a href="index.php?page=onderwerp4&id=4">F1</a>
    </ul>
</body>
</html>