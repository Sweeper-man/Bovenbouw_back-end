<?php
    include "../includes/header.php";

    // $id = $_GET['id'];

    include "../includes/footer.php";
?>
<!-- jouw HTML met de inhoud over onderwerp 1 komt hier... -->