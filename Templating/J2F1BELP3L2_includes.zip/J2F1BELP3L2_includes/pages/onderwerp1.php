<!-- jouw HTML met de inhoud over onderwerp 1 komt hier... -->
<img src="images/badminton.webp">
Badminton is een olympische sport die wordt gespeeld met een racket en een shuttle. 
De shuttle, die gemaakt kan zijn van nylon of van veren, wordt over een net heen en weer geslagen met de rackets. 
Badminton wordt in een zaal gespeeld, zodat er geen hinder van wind en andere weersomstandigheden is.