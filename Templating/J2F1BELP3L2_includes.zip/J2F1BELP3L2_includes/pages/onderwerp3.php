<!-- jouw HTML met de inhoud over onderwerp 3 komt hier... -->
<img src="images/taekwondo.png">
Taekwondo is een Koreaanse ongewapende vechtkunst en vechtsport met de nadruk op zelfverdediging. 
Letterlijk vertaald betekent tae voet, kwon vuist en do de kunst van of de weg. 
Vrij vertaald betekent taekwondo: de weg van de voet en de vuist.