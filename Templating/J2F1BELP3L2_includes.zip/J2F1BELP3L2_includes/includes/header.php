<!-- jouw HTML voor een Header komt hier... 
Gebruik hier tenminste een header afbeelding en een menu
Zorg dat je in het menu bij elk item een url parameter zet
om te bepalen welke inhoud er ingeladen moet worden in je html
-->
<link rel="stylesheet" href="../css/style.css">

<ul>
    <li><a href="./index.php?id=0">Badminton</a></li>
    <li><a href="./onderwerp1.php?id=1">Boxen</a></li>
    <li><a href="./onderwerp2.php?id=2">Kickboxen</a></li>
    <li><a href="./onderwerp3.php?id=3">F1</a></li>
</ul>

<img src="../images/trein.jpg">