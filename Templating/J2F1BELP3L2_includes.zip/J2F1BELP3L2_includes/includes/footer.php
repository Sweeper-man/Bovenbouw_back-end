<!-- jouw HTML voor een Footer komt hier... 
Benoem hier ten minste je naam en de tijd
-->
<footer>
  <?php
    echo "Sean" . "<br>"; 
    echo date("Y/m/d");
  ?>
</footer>